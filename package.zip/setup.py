from setuptools import setup

setup(
    name='ai_tutor',
    version='0.2.1',
    py_modules=['ai_tutor']
)
