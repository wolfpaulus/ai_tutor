from setuptools import setup

setup(
    name='ai_tutor',
    version='0.2.0',
    py_modules=['ai_tutor']
)
