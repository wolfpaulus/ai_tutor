from setuptools import setup

setup(
    name='ai_tutor',
    version='0.2.5',
    py_modules=['ai_tutor']
)
