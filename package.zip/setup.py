from setuptools import setup

setup(
    name='ai_tutor',
    version='0.3.2',
    py_modules=['ai_tutor']
)
